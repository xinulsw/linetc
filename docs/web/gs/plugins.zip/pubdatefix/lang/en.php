<?php
$i18n = array(
  "PUBDATE" => "Publication Date"
);