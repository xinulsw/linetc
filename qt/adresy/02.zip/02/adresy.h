#ifndef ADRESY_H
#define ADRESY_H

#include <QWidget>

namespace Ui {
class adresy;
}

class adresy : public QWidget
{
    Q_OBJECT

public:
    explicit adresy(QWidget *parent = 0);
    ~adresy();

private:
    Ui::adresy *ui;
};

#endif // ADRESY_H
